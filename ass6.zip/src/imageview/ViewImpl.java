package imageview;

/**
 * This view impl class which implements view interface.
 */
public class ViewImpl implements View {
  @Override
  public String display(String s) {
    return s;
  }
}
